const SHEET_ID = 'MASUKKAN_ID_SPREADSHEET_ANDA_DI_SINI'; 

function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Loop - 3D Circle')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function saveMessage(username, message) {
  try {
    const sheet = SpreadsheetApp.openById(SHEET_ID).getActiveSheet();
    const timestamp = new Date();
    sheet.appendRow([timestamp, username, message]);
    return { success: true, message: "Pesan berhasil masuk ke satelit." };
  } catch (error) {
    return { success: false, error: error.toString() };
  }
}